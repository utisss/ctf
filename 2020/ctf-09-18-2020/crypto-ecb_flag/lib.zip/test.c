#include <stdlib.h>
#include <stdio.h>
#include "encrypt.h"

// Using a NIST test vector
int main() {
	const unsigned char key_test[16] = {0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c};
	const unsigned char in_test[16] = {0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96, 0xe9, 0x3d, 0x7e, 0x11, 0x73, 0x93, 0x17, 0x2a};
	const unsigned char out_test[16] = {0x3a, 0xd7, 0x7b, 0xb4, 0x0d, 0x7a, 0x36, 0x60, 0xa8, 0x9e, 0xca, 0xf3, 0x24, 0x66, 0xef, 0x97};
	
	unsigned char* key = malloc(16);
	unsigned char* in = malloc(16);
	unsigned char* out = malloc(16);
	
	for (size_t i = 0; i < 16; i++) {
		key[i] = key_test[i];
		in[i] = in_test[i];
	}
	
	ecb_encrypt_128(in, out, key, 16);
	
	fprintf(stderr, "Key:             ");
	print_file_hex(key, 16, stderr);
	fprintf(stderr, "Input:           ");
	print_file_hex(in, 16, stderr);
	fprintf(stderr, "Output:          ");
	print_file_hex(out, 16, stderr);
	fprintf(stderr, "Expected output: ");
	print_file_hex(out_test, 16, stderr);
	
	return 0;
}
