#include <stdlib.h>
#include <stdio.h>
#include "encrypt.h"

const unsigned char BLOCK_SIZE = 16;
const unsigned char KEY_SIZE = 16;

// must be 4 blocks
// key must be set
// in and out must be 16 byte aligned
void encrypt_quadblock_128(unsigned char* in, unsigned char* out);

// must be 1 block
// key must be set
// in and out must be 16 byte aligned
void encrypt_block_128(unsigned char* in, unsigned char* out);

// key must be 16 bytes
// key must be 16 byte aligned
void set_key_128(unsigned char* key);

unsigned char* byte_buffer(size_t len) {
	// assumes malloc will be successful
	unsigned char* out = (unsigned char*)malloc(len);
	return out;
}

void print_file_hex(const unsigned char* in, size_t len, FILE* f) {
	const char HEX_ALPHABET[16] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	
	fprintf(f, "0x");
	for (size_t i = 0; i < len; i++) {
		fprintf(f, "%c",HEX_ALPHABET[(in[i]&0xF0) >> 4]);
		fprintf(f, "%c",HEX_ALPHABET[(in[i]&0x0F)]);
	}
	fprintf(f, "\n");
}

// len must be multiple of a block size
// key must be 16 bytes
// in, out, and key must be 16 byte aligned
void ecb_encrypt_128(unsigned char* in, unsigned char* out, unsigned char* key, size_t len) {
	size_t i = 0;
	
	set_key_128(key);
	
	for(; i + (4 * BLOCK_SIZE) <= len; i+= (4 * BLOCK_SIZE)) {
		encrypt_quadblock_128(&in[i], &out[i]);
	}
	
	for(; i < len; i += BLOCK_SIZE) {
		encrypt_block_128(&in[i], &out[i]);
	}
}
