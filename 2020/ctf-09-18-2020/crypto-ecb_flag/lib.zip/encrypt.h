#ifndef ENCRYPT_H
#define ENCRYPT_H

// key must be 16 bytes
// key must be 16 byte aligned
// returns 0 if failed to randomly generate key
unsigned char rand_key_128(unsigned char* key);

unsigned char* byte_buffer(size_t len);
void print_file_hex(const unsigned char* in, size_t len, FILE* f);

// len must be multiple of a block size
// key must be 16 bytes
// in, out, and key must be 16 byte aligned
void ecb_encrypt_128(unsigned char* in, unsigned char* out, unsigned char* key, size_t len);

#endif
